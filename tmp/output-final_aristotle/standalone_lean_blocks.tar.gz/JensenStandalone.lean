import Mathlib
import RequestProject.ZeroCountJensen

/-!
# Jensen Formula & Zero-Count for ξ — Standalone & Unconditional

Isolated headlines of `RequestProject.ZeroCountJensen`:

* `xi_jensen_at_zero` — Jensen's formula specialised to the completed zeta `ξ`
  (the general Jensen identity is Mathlib's `MeromorphicOn.circleAverage_log_norm`;
  the content here is its application to the entire function `ξ`).
* `xi_zero_count_disk_bound` — the disk zero-counting bound
  `#{ρ ∈ B_R : ξ(ρ) = 0} ≤ C·R·log R`, the Jensen ⇒ density estimate.

Unlike Stirling/Digamma, the **external footprint is genuinely the ξ analytic
chain** (`ZeroCountJensen` imports `RiemannXiDecay`, `ZetaStripBound`,
`MellinPathToXi`): the zero count needs `ξ`'s order-≤1 growth, which is not
Mathlib content. So this is "as standalone as the result allows".

## Axiom footprint
`[propext, Classical.choice, Quot.sound]`.
-/

open Real Complex
open scoped BigOperators

noncomputable section

namespace JensenStandalone

/-- **Jensen's formula for `ξ` at the origin.**
The circle-average of `log‖ξ‖` over `|z| = R` equals the divisor-weighted sum of
`log(R/‖ρ‖)` over zeros `ρ` in the closed disk, plus `log‖ξ(0)‖`. -/
theorem xi_jensen_at_zero (R : ℝ) (hR : 0 < R) :
    circleAverage (fun s => Real.log ‖ZD.riemannXi s‖) 0 R
      = ∑ᶠ u, (MeromorphicOn.divisor ZD.riemannXi
                (Metric.closedBall (0 : ℂ) |R|)) u *
              Real.log (R * ‖u‖⁻¹)
        + Real.log ‖ZD.riemannXi 0‖ :=
  ZD.ZeroCount.xi_jensen_at_zero R hR

/-- **Disk zero-count bound for `ξ`.**
There are `C, R₀ > 0` with `#{ρ ∈ closedBall 0 R : ξ(ρ) = 0} ≤ C·R·log R` for all
`R ≥ R₀`. -/
theorem xi_zero_count_disk_bound :
    ∃ C > (0 : ℝ), ∃ R₀ > (0 : ℝ), ∀ R, R₀ ≤ R →
      ((Metric.closedBall (0 : ℂ) R ∩ {z | ZD.riemannXi z = 0}).ncard : ℝ)
        ≤ C * R * Real.log R :=
  ZD.ZeroCount.xi_zero_count_disk_bound

#print axioms xi_jensen_at_zero
#print axioms xi_zero_count_disk_bound

end JensenStandalone
